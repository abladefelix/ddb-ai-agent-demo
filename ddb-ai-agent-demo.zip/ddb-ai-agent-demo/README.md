# Daniel Development Bank AI Agent Demo

## Deploy to Azure

[![Deploy to Azure](https://aka.ms/deploytoazurebutton)](https://portal.azure.com/#create/Microsoft.Template/uri/{RAW_GITHUB_URL_TO_AZUREDEPLOY.JSON})

After deploying, follow the instructions in this README to run your backend and frontend.

## Post-Deployment
- Integrate Twilio for phone voice (instructions to be provided).
- Update backend to connect with Azure OpenAI for real chat intelligence.
